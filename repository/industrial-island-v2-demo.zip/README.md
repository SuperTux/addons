# SuperTux: Industrial Addon v2

## How to install:
Clone this repository into this repository into your user directory. 
for windows users, this will be something like "User\AppData\Roaming\SuperTux\"

## Licensing 
You are allowed to use anything from Industrial in your content. However, you **must** credit us (the industrial team, or the person who created the asset) in a way that ensures that the average player or viewer of that content can readily notice the credit and easily find this repository. More information about asset distribution can be found in the LICENSE file - the CC-BY-SA-4.0 license.