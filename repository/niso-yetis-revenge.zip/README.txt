#####################################################################################
################################### R  E  A  D  M  E ###################################
#####################################################################################

----------------------------------------------------------------------------------------------------------------------------------------------------
A:                                               How To Install "Yeti's Revenge"
----------------------------------------------------------------------------------------------------------------------------------------------------

Step 1: Supertux 0.3.3-SVN
-----------------------------------------------------
Download the latest version (at the moment: 0.3.3-SVN) of Supertux from the SVN. 


Step 2: zip-file to the right direction
-----------------------------------------------------

Only Move the whole zip-folder into your supertux2-directory. DO NOT UNZIP THE FILE!



----------------------------------------------------------------------------------------------------------------------------------------------------
B:                                                           What's New
----------------------------------------------------------------------------------------------------------------------------------------------------

I will not waste a lot of words. Play the game - most things are self-explanatory.
What you have to know is that there are 5 blue coins in every level (except boss fights). 
Collect them all and you'll get 3 lifes. 
Try to collect all coins and find all secrets. Some of them are very hard to find, but it's not impossible.
Most levels contain also one fishbox, which is very hard to find. Find them all to unlock some bonus-levels. 


----------------------------------------------------------------------------------------------------------------------------------------------------
C:                                                              Contact
----------------------------------------------------------------------------------------------------------------------------------------------------

You found bugs, have problems with a level or new ideas (e.g better english words for the dialogues?) 
So post it at the bugtracker or the supertux wiki.




----------------------------------------------------------------------------------------------------------------------------------------------------
D:                                                              THANKS to
----------------------------------------------------------------------------------------------------------------------------------------------------

I really want to thank lmh, who designed the fishbox counter. Great Work!