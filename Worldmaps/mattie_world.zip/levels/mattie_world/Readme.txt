Installation:

Simply move the "mattie_world" directory into the "levels" directory for SuperTux.  Access should be available in the "Contrib Levels" option in the SuperTux main menu.

Licence: GPL 2 / CC-by-sa 3.0

Update: July 2010

I made the unfortunate discovery that the June 2010 update was in fact designed for a hybrid version of SuperTux (between the development snapshot and SVN).  As such, I have redone the levels to be in line with SuperTux version SVN r6640 to take advantage of more recent features.  The set will still work with the snapshot, but will probably be a bit buggy.  In addition, the following changes were made to the levelset:

- The Airship (and all associated levels) have moved away from Mattie's Iceberg.
- Rock Climbing and Arena also removed.
- The level set has been made considerably easier, but advanced players shouldn't fret as I've included the difficult levels in a preview of DOOM Islands- the next worldmap after Mattie's Iceberg.
- Badguy machine in Quarrelsome Quarry has been changed to account for badguys not being able to kill each other.
- Second secret area added to Dusky Dungeon.
- Minor visual tweaks throughout.
- Where's Waldo? bonus level made slightly less annoying to find secret areas (only slightly).
- Reduced badguy count in 3 Magic Lanterns and Over the Wall.
- Reduced complexity/difficulty of Toad's Castle and Escape.
- Included credits.
- Added preview of DOOM Islands with difficult/incomplete levels.

Known bugs:
- Ice Flower Fail (kinda):  The ice flower power-ups which are not released from a "?" block now work mostly.  There is no sound upon grabbing them, but at least they now grant Tux the ability to throw iceballs.
- Random Death:  Some in-game objects cause Tux to die instantly when he approaches them (perhaps angle/speed dependent, I'm not sure).  This is the reason that the bouncy coils are spread out on floors that are covered with them (minimizes the likelihood of death).  I've also seen this problem while manipulating lanterns and landing on the edge of some unstable blocks or moving platforms which are close to each other.  I'm sorry if it happens to you, and I feel your pain.
- Meaningless Kill Count Stat: The "Max Fragging" level statistic is meaningless on levels with dispensers since dispensed baddies are counted.  These include levels 2, 3, 7, and all boss levels.  Also for some reason the angrystones in level 11 are included in total number of enemies to be killed even though they are unkillable (5 is the maximum number of enemies to kill on this level).
- Badguy Falling From Above: On occasion I've found that sometimes a badguy will fall through the unisolid tiles on levels that scroll up/down.  It happens off screen and may be due to badguys landing on top of each other.  If you find badguys on the wrong platform this may be the cause.

I hope the changes make the level set available to a broader audience.  Novice players may not want to play the preview of DOOM Islands, but I hope they provide a challenge for advanced players.  As always and comments, suggestions, complaints or ideas can be sent to:

lmh.0013@gmail.com

---

Update: June 2010

Levels have been updated for use with SuperTux development version 0.3.3.  No testing has been done with earlier versions, and it is not expected that anything will work with versions earlier than 0.3.3.

In addition, the number of levels has been doubled.  Instead of 8 levels + 2 bonus of the original release, there are now 13 levels + 3 boss levels (1 previously as a numbered level) + 4 bonus levels.  Most changes to the original set have been environmental, with new features used to make them more in line with my original design concept.  Some difficulty tweaks have also been made.  All levels should work (and look good) with the higher resolution settings.

I hope the levels contain challenges which players find fun and/or unique.  I generally try to do something new in every level I make (not always with success) and hope someone will think some part somewhere is cool or neat.  As always, complements, criticisms, suggestions, and favorite curse while attempting the airship level can be sent to:

lmh.0013@gmail.com

---

Release: August 2008

The enclosed set of levels (8 regular and 2 bonus, plus world map) were created for use with SuperTux development version 0.3.1, although I have no evidence that they won't work on the non-development version.  The levels were built using a custom level creator and tested in the Mac OS X build of SuperTux (seems to work on Windows as well, my Linux system is currently "under construction").  

The levels themselves are meant to be a semi-challenging collection for a wide range of player skill levels.  Most can be beat in less than a minute; however, bonus areas and collecting all the coins are more of a challenge.  My intentions were a set of levels which did not rely on timing/precision, or deceptive tilesets as a means for difficulty (excepting one of the bonus stages).  

I hope some of the content and challenges are new and enjoyable to players.  Feel free to send comments and criticisms to: 

lmh.0013@gmail.com
